#!/usr/bin/env node
/**
 * hokkaクイズラリー - 強化版サーバー
 * 作成日: 2025-07-14
 * 
 * 新機能:
 * - アドミンアカウント
 * - 実際のデータベース機能（メモリベース）
 * - ユーザー名重複チェック
 * - アドミン問題管理
 * - 実際のランキングデータ
 * - 200名同時接続対応
 * - CSV出力機能
 * - アドミン専用ユーザー作成
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');
const crypto = require('crypto');

// 分離されたデータベースモジュールをインポート
const Database = require('./database.js');

const PORT = 8080;
const HOST = '0.0.0.0';

// 200名同時接続対応設定
const MAX_CONNECTIONS = 200;
const TIMEOUT = 30000; // 30秒タイムアウト
const KEEP_ALIVE_TIMEOUT = 65000; // 65秒
const HEADERS_TIMEOUT = 66000; // 66秒

console.log('🦫 hokkaクイズラリー 強化版サーバーを起動中...');
console.log('='.repeat(50));

// 接続数管理
let currentConnections = 0;

// Databaseモジュールは外部ファイルから読み込み済み
const Database = {
  users: new Map(),
  questions: new Map(),
  userAnswers: new Map(),
  quizSessions: new Map(),
  rankings: new Map(),
  surveyAnswers: new Map(),
  quizCompletions: new Map(), // クイズ完了状況を追跡
  
  // データをファイルに保存
  saveToFile() {
    try {
      const data = {
        users: Array.from(this.users.entries()),
        questions: Array.from(this.questions.entries()),
        userAnswers: Array.from(this.userAnswers.entries()),
        quizSessions: Array.from(this.quizSessions.entries()),
        rankings: Array.from(this.rankings.entries()),
        surveyAnswers: Array.from(this.surveyAnswers.entries()),
        quizCompletions: Array.from(this.quizCompletions.entries()),
        timestamp: new Date().toISOString()
      };
      
      fs.writeFileSync(path.join(DATA_DIR, 'database.json'), JSON.stringify(data, null, 2));
      console.log('✅ データを保存しました');
    } catch (error) {
      console.error('❌ データ保存エラー:', error.message);
    }
  },
  
  // ファイルからデータを読み込み
  loadFromFile() {
    try {
      const filePath = path.join(DATA_DIR, 'database.json');
      if (!fs.existsSync(filePath)) {
        console.log('📄 データファイルが見つかりません。新規作成します');
        return false;
      }
      
      const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      
      this.users = new Map(data.users || []);
      this.questions = new Map(data.questions || []);
      this.userAnswers = new Map(data.userAnswers || []);
      this.quizSessions = new Map(data.quizSessions || []);
      this.rankings = new Map(data.rankings || []);
      this.surveyAnswers = new Map(data.surveyAnswers || []);
      this.quizCompletions = new Map(data.quizCompletions || []);
      
      console.log(`✅ データを復元しました (${data.timestamp || '不明'})`);
      console.log(`👥 ユーザー数: ${this.users.size}, 📝 解答数: ${this.userAnswers.size}`);
      return true;
    } catch (error) {
      console.error('❌ データ読み込みエラー:', error.message);
      return false;
    }
  },
  
  // 初期データ設定
  init() {
    // まずファイルからデータを復元を試行
    const restored = this.loadFromFile();
    if (restored) {
      // データが復元された場合は初期データ設定をスキップ
      // データ整合性チェックを実行
      this.checkDataIntegrity();
      return;
    }
    
    // データが復元できなかった場合のみ初期データを設定
    console.log('🔧 初期データを作成します');
    
    // デフォルトアドミンユーザー
    this.users.set(1, {
      id: 1,
      nickname: 'admin',
      real_name: 'システム管理者',
      age_group: 'adult',
      gender: 'other',
      password_hash: this.hashPassword('admin123'),
      is_admin: true,
      created_at: new Date()
    });

    // デフォルト問題データ（北陸製菓の企業理念・企業努力に特化）
    const defaultQuestions = [
      {
        id: 1,
        question_number: 1,
        question_text: '北陸製菓の会社ができたのはいつでしょうか？',
        choice_a: '大正7年（1918年）',
        choice_b: '昭和25年（1950年）',
        choice_c: '昭和40年（1965年）',
        choice_d: '昭和45年（1970年）',
        correct_answer: 'A',
        explanation: '北陸製菓は大正7年（1918年）に創業しました。100年以上もの長い歴史を持つ老舗のお菓子会社で、長年にわたってみんなに愛される美味しいお菓子を作り続けています。'
      },
      {
        id: 2,
        question_number: 2,
        question_text: '北陸製菓が一番大切にしていることで正しいのはどれでしょうか？',
        choice_a: '安い商品をたくさん作る',
        choice_b: 'お客様に喜んでもらえる商品作り',
        choice_c: '新しい商品だけを作る',
        choice_d: '機械だけで作る',
        correct_answer: 'B',
        explanation: '北陸製菓は「お客様に喜んでもらえる商品作り」を一番大切にしています。美味しくて安全なお菓子を作って、みんなが笑顔になれるように心を込めて作っています。'
      },
      {
        id: 3,
        question_number: 3,
        question_text: '北陸製菓の「ビーバー」というお菓子の特徴はどれでしょうか？',
        choice_a: 'チョコレート味だけ',
        choice_b: '固くて食べにくい',
        choice_c: 'サクサクした食感',
        choice_d: '冷たいお菓子',
        correct_answer: 'C',
        explanation: 'ビーバーはサクサクした軽い食感が特徴のお菓子です。北陸製菓の技術と工夫により、誰でも食べやすく美味しいお菓子として多くの人に愛されています。'
      },
      {
        id: 4,
        question_number: 4,
        question_text: '北陸製菓が商品を作るときに一番気をつけていることは何でしょうか？',
        choice_a: '早く作ること',
        choice_b: '安全で美味しいこと',
        choice_c: '見た目だけきれいにすること',
        choice_d: '安い材料を使うこと',
        correct_answer: 'B',
        explanation: '北陸製菓では「安全で美味しいこと」を一番大切にしています。みんなが安心して食べられるように、きちんと確認して美味しいお菓子を作っています。'
      },
      {
        id: 5,
        question_number: 5,
        question_text: '北陸製菓の工場では、どのような工夫をしているでしょうか？',
        choice_a: '機械だけで作っている',
        choice_b: '衛生管理を徹底している',
        choice_c: '外で作っている',
        choice_d: '一人だけで作っている',
        correct_answer: 'B',
        explanation: '北陸製菓の工場ではとてもきれいにしています。清潔で安全なお菓子を作るために、働く人みんなで協力して美味しいお菓子作りをしています。'
      },
      {
        id: 6,
        question_number: 6,
        question_text: '北陸製菓が地域のために行っている活動はどれでしょうか？',
        choice_a: '地元の材料を使う',
        choice_b: '工場見学を受け入れる',
        choice_c: '地域のイベントに参加する',
        choice_d: '上記すべて',
        correct_answer: 'D',
        explanation: '北陸製菓は地域との繋がりを大切にしています。地元の材料を使ったり、工場見学を受け入れたり、地域のイベントに参加するなど、地域の皆さんと一緒に成長することを大切にしています。'
      },
      {
        id: 7,
        question_number: 7,
        question_text: '北陸製菓の商品づくりで大切にしている「伝統」とは何でしょうか？',
        choice_a: '昔からの美味しい作り方',
        choice_b: '古い機械だけを使う',
        choice_c: '同じ味だけを作る',
        choice_d: '昔の包装紙を使う',
        correct_answer: 'A',
        explanation: '北陸製菓では「昔からの美味しい作り方」という伝統を大切にしています。長年培ってきた技術や製法を受け継ぎながら、より美味しい商品を作る努力を続けています。'
      },
      {
        id: 8,
        question_number: 8,
        question_text: '北陸製菓が環境のために取り組んでいることはどれでしょうか？',
        choice_a: 'ゴミを減らす努力',
        choice_b: 'エネルギーを大切に使う',
        choice_c: '包装材料を工夫する',
        choice_d: '上記すべて',
        correct_answer: 'D',
        explanation: '北陸製菓は環境を守るために様々な取り組みをしています。ゴミを減らし、エネルギーを大切に使い、包装材料も環境に優しいものを選ぶなど、地球に優しい会社を目指しています。'
      },
      {
        id: 9,
        question_number: 9,
        question_text: '北陸製菓が新しい商品を作るときに大切にしていることは何でしょうか？',
        choice_a: 'お客様の声を聞く',
        choice_b: '何度も試作を重ねる',
        choice_c: '安全性を確認する',
        choice_d: '上記すべて',
        correct_answer: 'D',
        explanation: '北陸製菓では新商品開発時に、お客様の声を大切にし、何度も試作を重ね、安全性をしっかり確認しています。みんなに喜んでもらえる商品を作るための努力を惜しみません。'
      },
      {
        id: 10,
        question_number: 10,
        question_text: '北陸製菓の「働く人」を大切にする取り組みはどれでしょうか？',
        choice_a: '安全な職場作り',
        choice_b: '技術の勉強会',
        choice_c: '働きやすい環境作り',
        choice_d: '上記すべて',
        correct_answer: 'D',
        explanation: '北陸製菓では働く人を大切にし、安全な職場作り、技術向上のための勉強会、働きやすい環境作りに取り組んでいます。みんなが協力して良い商品を作れるよう努力しています。'
      }
    ];

    defaultQuestions.forEach(q => this.questions.set(q.id, q));

    // テスト用ユーザー作成
    this.createTestUsers();
  },

  // パスワードハッシュ化
  hashPassword(password) {
    return crypto.createHash('sha256').update(password + 'salt').digest('hex');
  },

  // ユーザー登録
  createUser(userData) {
    // ニックネーム重複チェック
    for (let user of this.users.values()) {
      if (user.nickname === userData.nickname) {
        throw new Error(`${userData.nickname} は既に登録されています`);
      }
    }

    const id = this.users.size + 1;
    const user = {
      id,
      nickname: userData.nickname,
      real_name: userData.real_name || userData.nickname,
      age_group: userData.age_group,
      gender: userData.gender,
      password_hash: this.hashPassword(userData.password),
      is_admin: false,
      created_at: new Date()
    };

    this.users.set(id, user);
    this.saveToFile(); // データを保存
    console.log(`✅ ユーザー作成: ${user.nickname} (ID: ${user.id})`);
    return { ...user, password_hash: undefined };
  },

  // ログイン認証
  authenticateUser(nickname, password) {
    const hashedPassword = this.hashPassword(password);
    for (let user of this.users.values()) {
      if (user.nickname === nickname && user.password_hash === hashedPassword) {
        console.log(`✅ 認証成功: ${nickname} (ID: ${user.id}, Admin: ${user.is_admin})`);
        return { ...user, password_hash: undefined };
      }
    }
    console.log(`❌ 認証失敗: ${nickname} (パスワード不一致)`);
    return null;
  },

  // テスト用ユーザー作成
  createTestUsers() {
    const testUsers = [
      { nickname: 'test', password: 'test123', age_group: 'adult', gender: 'other' },
      { nickname: 'aaa', password: 'aaa123', age_group: 'adult', gender: 'other' },
      { nickname: 'sample', password: 'sample123', age_group: 'elementary', gender: 'male' }
    ];

    testUsers.forEach(userData => {
      try {
        this.createUser(userData);
      } catch (error) {
        console.log(`テストユーザー ${userData.nickname} はスキップされました`);
      }
    });
  },

  // 問題の追加/更新（アドミン用）
  saveQuestion(questionData) {
    const id = questionData.id || this.questions.size + 1;
    const question = {
      id,
      question_number: questionData.question_number,
      question_text: questionData.question_text,
      choice_a: questionData.choice_a,
      choice_b: questionData.choice_b,
      choice_c: questionData.choice_c,
      choice_d: questionData.choice_d,
      correct_answer: questionData.correct_answer,
      explanation: questionData.explanation || '',
      created_at: new Date()
    };

    this.questions.set(id, question);
    return question;
  },

  // 解答保存（完了後は編集不可）
  saveUserAnswer(userId, questionNumber, answer) {
    const key = `${userId}_${questionNumber}`;
    const question = Array.from(this.questions.values()).find(q => q.question_number === questionNumber);
    const isCorrect = question ? answer === question.correct_answer : false;

    // クイズ完了チェック - 完了後は一切の編集を禁止
    const isQuizCompleted = this.quizCompletions.has(userId);
    if (isQuizCompleted) {
      throw new Error('クイズは既に完了しています。再回答はできません。');
    }

    // 既存の解答がある場合は更新（完了前のみ編集可能）
    const existingAnswer = this.userAnswers.get(key);
    if (existingAnswer) {
      console.log(`📝 問題 ${questionNumber} の解答を更新: ${existingAnswer.selected_answer} → ${answer}`);
    }

    const userAnswer = {
      user_id: userId,
      question_number: questionNumber,
      selected_answer: answer,
      is_correct: isCorrect,
      answered_at: new Date()
    };

    this.userAnswers.set(key, userAnswer);
    this.saveToFile(); // データを保存
    return userAnswer;
  },

  // ユーザー解答取得
  getUserAnswers(userId) {
    const answers = {};
    for (let questionNum = 1; questionNum <= 10; questionNum++) {
      const key = `${userId}_${questionNum}`;
      const userAnswer = this.userAnswers.get(key);
      if (userAnswer) {
        answers[questionNum] = userAnswer.selected_answer;
      }
    }
    return answers;
  },

  // クイズ完了処理（アンケート済みの場合はボーナス自動追加）
  completeQuiz(userId, answers) {
    // 既に完了チェック
    if (this.quizCompletions.has(userId)) {
      throw new Error('クイズは既に完了しています。再提出はできません。');
    }

    // 管理者の場合はランキングに追加しない（テスト用）
    const user = this.users.get(userId);
    if (user && user.is_admin) {
      console.log(`🧪 管理者テスト完了: ${user.nickname} - テスト実行のためランキング対象外`);
      // 完了記録は作成するがランキングには入れない
      const answerCount = this.getUserAnswerCount(userId);
      let correctCount = 0;
      let score = 0;

      for (let questionNum = 1; questionNum <= 10; questionNum++) {
        const key = `${userId}_${questionNum}`;
        const userAnswer = this.userAnswers.get(key);
        if (userAnswer && userAnswer.is_correct) {
          correctCount++;
          score += 10;
        }
      }

      this.quizCompletions.set(userId, {
        completed_at: new Date(),
        total_questions: 10,
        answered_questions: answerCount,
        correct_count: correctCount,
        base_score: score
      });

      this.saveToFile();
      return { correctCount, score, baseScore: score, surveyBonus: 0 };
    }

    // 一般ユーザーの通常処理
    const result = this._performQuizCompletion(userId, this.getUserAnswerCount(userId));
    this.saveToFile();
    return result;
  },

  // アンケート回答保存（ボーナスポイント適切処理）
  submitSurvey(userId, surveyData) {
    // 既にアンケート回答済みかチェック
    if (this.surveyAnswers.has(userId)) {
      throw new Error('アンケートは既に回答済みです。');
    }

    this.surveyAnswers.set(userId, {
      user_id: userId,
      answers: surveyData,
      submitted_at: new Date()
    });

    // クイズが完了している場合のみボーナスポイントを付与
    const isQuizCompleted = this.quizCompletions.has(userId);
    let bonusApplied = false;
    
    if (isQuizCompleted) {
      // ランキングエントリーを取得または作成
      let ranking = this.rankings.get(userId);
      
      if (ranking) {
        // 既存のランキングエントリーがある場合
        const previousBonus = ranking.survey_bonus || 0;
        ranking.survey_bonus = 10;
        ranking.final_score = ranking.final_score - previousBonus + 10;
        this.rankings.set(userId, ranking);
        console.log(`✅ ボーナスポイント追加: ${ranking.nickname} (+10点, 合計: ${ranking.final_score}点)`);
        bonusApplied = true;
      }
    } else {
      console.log(`⚠️ クイズ未完了のため、ボーナスポイントは保留されます（ユーザー${userId}）`);
    }
    
    this.saveToFile();
    return { success: true, bonus_applied: bonusApplied, bonus_points: bonusApplied ? 10 : 0 };
  },

  // ユーザー解答数取得
  getUserAnswerCount(userId) {
    let count = 0;
    for (let i = 1; i <= 10; i++) {
      const key = `${userId}_${i}`;
      if (this.userAnswers.has(key)) {
        count++;
      }
    }
    return count;
  },

  // データ整合性チェック機能
  checkDataIntegrity() {
    console.log('🔍 データ整合性をチェック中...');
    
    let fixedCount = 0;
    const allUserIds = new Set();
    
    // すべてのユーザーIDを収集
    this.users.forEach((user, id) => allUserIds.add(id));
    this.userAnswers.forEach((answer) => allUserIds.add(answer.user_id));
    
    // 各ユーザーの整合性をチェック
    allUserIds.forEach(userId => {
      const answerCount = this.getUserAnswerCount(userId);
      const isCompleted = this.quizCompletions.has(userId);
      
      // 10問すべて解答済みだが完了記録がない場合
      if (answerCount === 10 && !isCompleted) {
        console.log(`⚠️  不整合検出: ユーザー${userId} - 解答完了だが完了記録なし`);
        
        try {
          // 自動的にクイズ完了処理を実行
          this.autoCompleteQuiz(userId);
          fixedCount++;
          console.log(`✅ 修正完了: ユーザー${userId}の完了記録を作成`);
        } catch (error) {
          console.error(`❌ 修正エラー: ユーザー${userId} - ${error.message}`);
        }
      }
      
      // 完了記録があるが解答が不足している場合（警告のみ）
      if (isCompleted && answerCount < 10) {
        console.log(`⚠️  警告: ユーザー${userId} - 完了記録あり(${answerCount}/10問解答)`);
      }
    });
    
    if (fixedCount > 0) {
      console.log(`🔧 データ整合性修正: ${fixedCount}件の不整合を修正しました`);
      this.saveToFile(); // 修正後にデータを保存
    } else {
      console.log('✅ データ整合性チェック完了: 問題なし');
    }
  },

  // 自動クイズ完了処理（整合性修正用）
  autoCompleteQuiz(userId) {
    // 既に完了している場合はスキップ
    if (this.quizCompletions.has(userId)) {
      return;
    }

    // 共通処理を使用して重複を排除（10問確実に解答済み）
    const result = this._performQuizCompletion(userId, 10);
    console.log(`🎯 自動完了処理: ユーザー${userId} - ${result.correctCount}/10問正解, ${result.score}点`);
  },

  // クイズ完了の共通処理（重複排除）
  _performQuizCompletion(userId, answeredQuestions) {
    let correctCount = 0;
    let score = 0;

    // 既存の解答から成績を計算
    for (let questionNum = 1; questionNum <= 10; questionNum++) {
      const key = `${userId}_${questionNum}`;
      const userAnswer = this.userAnswers.get(key);
      if (userAnswer && userAnswer.is_correct) {
        correctCount++;
        score += 10;
      }
    }

    // クイズ完了記録を作成
    this.quizCompletions.set(userId, {
      completed_at: new Date(),
      total_questions: 10,
      answered_questions: answeredQuestions,
      correct_count: correctCount,
      base_score: score
    });

    // アンケート回答状況をチェック
    const hasSurvey = this.surveyAnswers.has(userId);
    const surveyBonus = hasSurvey ? 10 : 0;
    const finalScore = score + surveyBonus;

    // ランキングに追加（存在しない場合のみ）
    if (!this.rankings.has(userId)) {
      const user = this.users.get(userId);
      if (user) {
        this.rankings.set(userId, {
          user_id: userId,
          nickname: user.nickname,
          age_group: user.age_group,
          final_score: finalScore,
          correct_answers: correctCount,
          total_questions: 10,
          completion_time: new Date(),
          survey_bonus: surveyBonus
        });

        console.log(`📊 クイズ完了: ${user.nickname} - ${correctCount}/10問正解, ${finalScore}点`);
      }
    }

    return { correctCount, score: finalScore, baseScore: score, surveyBonus };
  },

  // ランキング取得
  getRankings() {
    const rankings = Array.from(this.rankings.values())
      .sort((a, b) => {
        if (a.final_score !== b.final_score) {
          return b.final_score - a.final_score;
        }
        return new Date(a.completion_time) - new Date(b.completion_time);
      });

    return rankings;
  },

  // CSV出力用データ生成
  generateScoreCSV() {
    const rankings = this.getRankings();
    const csvData = [
      ['順位', 'ニックネーム', '年齢層', '正解数', '基本スコア', 'アンケートボーナス', '最終スコア', '完了時刻']
    ];

    rankings.forEach((ranking, index) => {
      csvData.push([
        index + 1,
        ranking.nickname,
        ranking.age_group,
        ranking.correct_answers,
        ranking.final_score - ranking.survey_bonus,
        ranking.survey_bonus,
        ranking.final_score,
        new Date(ranking.completion_time).toLocaleString('ja-JP')
      ]);
    });

    return csvData.map(row => row.join(',')).join('\n');
  },

  generateSurveyCSV() {
    const surveys = Array.from(this.surveyAnswers.values());
    const csvData = [['ユーザーID', '回答1', '回答2', '提出時刻']];

    surveys.forEach(survey => {
      const user = this.users.get(survey.user_id);
      csvData.push([
        user?.nickname || survey.user_id,
        survey.answers.q1 || '',
        survey.answers.q2 || '',
        new Date(survey.submitted_at).toLocaleString('ja-JP')
      ]);
    });

    return csvData.map(row => row.join(',')).join('\n');
  },

  generateQuestionAnalysisCSV() {
    const questions = Array.from(this.questions.values()).sort((a, b) => a.question_number - b.question_number);
    const csvData = [['問題番号', '問題文', '正解', '正答率', '選択肢A', '選択肢B', '選択肢C', '選択肢D']];

    questions.forEach(question => {
      const answers = Array.from(this.userAnswers.values()).filter(a => a.question_number === question.question_number);
      const correctAnswers = answers.filter(a => a.is_correct).length;
      const totalAnswers = answers.length;
      const correctRate = totalAnswers > 0 ? (correctAnswers / totalAnswers * 100).toFixed(1) : 0;

      csvData.push([
        question.question_number,
        question.question_text,
        question.correct_answer,
        `${correctRate}%`,
        question.choice_a,
        question.choice_b,
        question.choice_c,
        question.choice_d
      ]);
    });

    return csvData.map(row => row.join(',')).join('\n');
  }
};

// MIMEタイプ
const mimeTypes = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css',
  '.js': 'application/javascript',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml'
};

function getMimeType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  return mimeTypes[ext] || 'text/plain';
}

// サーバー処理
const server = http.createServer(async (req, res) => {
  const parsedUrl = url.parse(req.url, true);
  let pathname = parsedUrl.pathname;
  
  console.log(`📍 ${req.method} ${pathname}`);
  
  // CORS設定
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }
  
  // POSTデータ読み取り
  const getBody = () => {
    return new Promise((resolve) => {
      let body = '';
      req.on('data', chunk => {
        body += chunk.toString();
      });
      req.on('end', () => {
        try {
          resolve(JSON.parse(body));
        } catch (error) {
          resolve({});
        }
      });
    });
  };
  
  // 静的ファイル配信
  if (pathname.startsWith('/css/') || pathname.startsWith('/js/') || pathname.startsWith('/images/')) {
    const filePath = path.join(__dirname, 'public', pathname);
    
    if (fs.existsSync(filePath)) {
      const mimeType = getMimeType(filePath);
      res.writeHead(200, { 'Content-Type': mimeType });
      fs.createReadStream(filePath).pipe(res);
      return;
    }
  }
  
  // HTML テンプレート配信
  if (pathname === '/' || pathname === '/index.html') {
    const filePath = path.join(__dirname, 'templates', 'index.html');
    if (fs.existsSync(filePath)) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      fs.createReadStream(filePath).pipe(res);
      return;
    }
  }
  
  // その他のHTMLページ
  const htmlPages = ['login', 'register', 'mypage', 'quiz', 'ranking', 'survey', 'admin', 'result', 'review'];
  if (htmlPages.includes(pathname.replace('/', ''))) {
    const filePath = path.join(__dirname, 'templates', pathname.replace('/', '') + '.html');
    if (fs.existsSync(filePath)) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      fs.createReadStream(filePath).pipe(res);
      return;
    }
  }
  
  // 認証API（一般ユーザー登録は無効化）
  if (pathname === '/api/auth/register' && req.method === 'POST') {
    res.writeHead(403, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: '新規登録は受付スタッフにお申し出ください' }));
    return;
  }
  
  // アドミン専用ユーザー作成API
  if (pathname === '/api/admin/users' && req.method === 'POST') {
    const data = await getBody();
    try {
      const user = Database.createUser(data);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, user }));
    } catch (error) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: error.message }));
    }
    return;
  }
  
  // ログインAPI
  if (pathname === '/api/auth/login' && req.method === 'POST') {
    const { nickname, password } = await getBody();
    
    console.log(`ログイン試行: ${nickname}`);
    
    const user = Database.authenticateUser(nickname, password);
    
    if (user) {
      console.log(`ログイン成功: ${nickname} (ID: ${user.id})`);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, user }));
    } else {
      console.log(`ログイン失敗: ${nickname}`);
      res.writeHead(401, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'ニックネームまたはパスワードが正しくありません' }));
    }
    return;
  }

  // 問題API
  if (pathname === '/api/quiz/questions') {
    const questions = Array.from(Database.questions.values()).sort((a, b) => a.question_number - b.question_number);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ questions }));
    return;
  }

  // 解答保存API
  if (pathname === '/api/quiz/save-answer' && req.method === 'POST') {
    const { userId, questionNumber, answer } = await getBody();
    try {
      const userAnswer = Database.saveUserAnswer(userId, questionNumber, answer);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, userAnswer }));
    } catch (error) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  // 解答保存API (フロントエンド互換)
  if (pathname === '/api/quiz/answer' && req.method === 'POST') {
    const { userId, questionNumber, answer } = await getBody();
    console.log(`📝 解答保存: ユーザー${userId} 問題${questionNumber} 解答${answer}`);
    
    try {
      const userAnswer = Database.saveUserAnswer(userId, questionNumber, answer);
      console.log(`✅ 解答保存成功: ${JSON.stringify(userAnswer)}`);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, userAnswer }));
    } catch (error) {
      console.error(`❌ 解答保存エラー: ${error.message}`);
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  // 解答取得API
  if (pathname.match(/^\/api\/quiz\/answers\/(\d+)$/) && req.method === 'GET') {
    const userId = parseInt(pathname.split('/')[4]);
    console.log(`📖 解答取得: ユーザー${userId}`);
    
    try {
      const answers = Database.getUserAnswers(userId);
      console.log(`✅ 解答取得成功: ${JSON.stringify(answers)}`);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ answers }));
    } catch (error) {
      console.error(`❌ 解答取得エラー: ${error.message}`);
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  // クイズ状態取得API
  if (pathname.match(/^\/api\/quiz\/status\/(\d+)$/) && req.method === 'GET') {
    const userId = parseInt(pathname.split('/')[4]);
    console.log(`📊 クイズ状態取得: ユーザー${userId}`);
    
    try {
      const isCompleted = Database.quizCompletions.has(userId);
      const answers = Database.getUserAnswers(userId);
      const answeredCount = Object.keys(answers).length;
      
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ 
        isCompleted, 
        answeredCount, 
        totalQuestions: 10 
      }));
    } catch (error) {
      console.error(`❌ クイズ状態取得エラー: ${error.message}`);
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  // クイズ完了API
  if (pathname === '/api/quiz/submit' && req.method === 'POST') {
    const { userId } = await getBody();
    console.log(`🏁 クイズ完了処理: ユーザー${userId}`);
    
    try {
      const result = Database.completeQuiz(userId, {});
      console.log(`✅ クイズ完了成功: ${JSON.stringify(result)}`);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, result }));
    } catch (error) {
      console.error(`❌ クイズ完了エラー: ${error.message}`);
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  // アンケート状態確認API
  if (pathname.startsWith('/api/survey/status/') && req.method === 'GET') {
    const userId = parseInt(pathname.split('/').pop());
    console.log(`📋 アンケート状態取得: ユーザー${userId}`);
    
    try {
      const isCompleted = Database.surveyAnswers.has(userId);
      const surveyData = Database.surveyAnswers.get(userId);
      
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        completed: isCompleted,
        submittedAt: surveyData ? surveyData.submitted_at : null
      }));
    } catch (error) {
      console.error(`❌ アンケート状態取得エラー: ${error.message}`);
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  // アンケート提出API（ボーナスポイント適切処理）
  if (pathname === '/api/survey/submit' && req.method === 'POST') {
    const { userId, answers } = await getBody();
    console.log('📝 アンケート提出:', `ユーザー${userId}`, answers);
    try {
      const result = Database.submitSurvey(userId, answers);
      if (result.bonus_applied) {
        console.log('✅ アンケート提出成功: +10ボーナスポイント付与');
      } else {
        console.log('✅ アンケート提出成功: ボーナスはクイズ完了後に付与されます');
      }
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ 
        success: true, 
        bonus_points: result.bonus_points,
        bonus_applied: result.bonus_applied,
        message: result.bonus_applied 
          ? '10ポイントのボーナスが追加されました！' 
          : 'アンケートありがとうございます。クイズ完了後にボーナスポイントが追加されます。'
      }));
    } catch (error) {
      console.error('❌ アンケート提出エラー:', error);
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  // ランキングAPI
  if (pathname === '/api/ranking') {
    const rankings = Database.getRankings();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ rankings }));
    return;
  }

  // デバッグ用ユーザー一覧API
  if (pathname === '/api/debug/users') {
    const users = Array.from(Database.users.values()).map(user => ({
      id: user.id,
      nickname: user.nickname,
      age_group: user.age_group,
      gender: user.gender,
      is_admin: user.is_admin,
      password_hash: user.password_hash ? user.password_hash.substring(0, 10) + '...' : 'なし',
      password_exists: !!user.password_hash
    }));
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ users, total: users.length }));
    return;
  }

  // アドミン問題管理API
  if (pathname === '/api/admin/questions' && req.method === 'POST') {
    const questionData = await getBody();
    try {
      const question = Database.saveQuestion(questionData);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, question }));
    } catch (error) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  // アドミン問題更新API
  if (pathname.startsWith('/api/admin/questions/') && req.method === 'PUT') {
    const questionId = parseInt(pathname.split('/')[4]);
    const questionData = await getBody();
    
    if (Database.questions.has(questionId)) {
      // 既存の問題を更新
      const updatedQuestion = {
        ...Database.questions.get(questionId),
        ...questionData,
        id: questionId, // IDは変更不可
        updated_at: new Date()
      };
      
      Database.questions.set(questionId, updatedQuestion);
      Database.saveToFile();
      
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, question: updatedQuestion }));
    } else {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: '問題が見つかりません' }));
    }
    return;
  }

  // アドミン問題削除API
  if (pathname.startsWith('/api/admin/questions/') && req.method === 'DELETE') {
    const questionId = parseInt(pathname.split('/')[4]);
    
    if (Database.questions.has(questionId)) {
      Database.questions.delete(questionId);
      Database.saveToFile();
      
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, message: '問題を削除しました' }));
    } else {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: '問題が見つかりません' }));
    }
    return;
  }

  // CSV出力API
  if (pathname === '/api/admin/export/scores') {
    const csvData = '\ufeff' + Database.generateScoreCSV(); // BOM付きUTF-8
    res.writeHead(200, { 
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': 'attachment; filename="quiz_scores.csv"'
    });
    res.end(csvData);
    return;
  }

  if (pathname === '/api/admin/export/survey') {
    const csvData = '\ufeff' + Database.generateSurveyCSV(); // BOM付きUTF-8
    res.writeHead(200, { 
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': 'attachment; filename="survey_results.csv"'
    });
    res.end(csvData);
    return;
  }

  if (pathname === '/api/admin/export/questions') {
    const csvData = '\ufeff' + Database.generateQuestionAnalysisCSV(); // BOM付きUTF-8
    res.writeHead(200, { 
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': 'attachment; filename="question_analysis.csv"'
    });
    res.end(csvData);
    return;
  }

  if (pathname === '/api/admin/export/full') {
    const scoreData = Database.generateScoreCSV();
    const surveyData = Database.generateSurveyCSV();
    const questionData = Database.generateQuestionAnalysisCSV();
    
    const fullReport = `=== 成績データ ===\n${scoreData}\n\n=== アンケート結果 ===\n${surveyData}\n\n=== 問題分析 ===\n${questionData}`;
    
    res.writeHead(200, { 
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': 'attachment; filename="full_report.csv"'
    });
    res.end('\ufeff' + fullReport);
    return;
  }

  // 404 エラー
  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('404 Not Found');
});

// 接続管理
server.on('connection', (socket) => {
  currentConnections++;
  console.log(`🔗 新規接続 (現在: ${currentConnections}/${MAX_CONNECTIONS})`);
  
  socket.setTimeout(TIMEOUT);
  socket.on('timeout', () => {
    console.log('⏰ 接続タイムアウト');
    socket.destroy();
  });
  
  socket.on('close', () => {
    currentConnections--;
    console.log(`❌ 接続終了 (現在: ${currentConnections}/${MAX_CONNECTIONS})`);
  });
});

// サーバー設定
server.maxConnections = MAX_CONNECTIONS;
server.timeout = TIMEOUT;
server.keepAliveTimeout = KEEP_ALIVE_TIMEOUT;
server.headersTimeout = HEADERS_TIMEOUT;

// データベース初期化
Database.init();

// サーバー起動
server.listen(PORT, HOST, () => {
  console.log('✅ アプリケーションの初期化完了');
  console.log(`📍 アクセスURL: http://localhost:${PORT}`);
  console.log(`📍 アクセスURL: http://127.0.0.1:${PORT}`);
  console.log(`📍 WSL2アクセスURL: http://172.20.251.113:${PORT}`);
  console.log(`🔗 最大同時接続数: ${MAX_CONNECTIONS}名`);
  console.log('👤 アドミンアカウント: admin / admin123');
  console.log('👤 テストアカウント: test / test123, aaa / aaa123');
  console.log('📊 CSV出力機能: 利用可能');
  console.log('🛑 停止するには Ctrl+C を押してください');
  console.log('='.repeat(50));
});

// エラー処理
process.on('uncaughtException', (error) => {
  console.error('❌ 予期しないエラー:', error);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ 未処理のPromise拒否:', reason);
});