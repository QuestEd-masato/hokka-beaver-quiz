// テストログインスクリプト
const http = require('http');

// テストユーザーを作成
function createTestUser() {
  const userData = JSON.stringify({
    nickname: 'test',
    password: 'test123',
    age_group: 'adult',
    gender: 'male'
  });

  const options = {
    hostname: 'localhost',
    port: 3000,
    path: '/api/auth/register',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': userData.length
    }
  };

  const req = http.request(options, (res) => {
    let data = '';
    res.on('data', (chunk) => data += chunk);
    res.on('end', () => {
      console.log('ユーザー作成結果:', res.statusCode, data);
      if (res.statusCode === 200) {
        testLogin();
      }
    });
  });

  req.on('error', (e) => {
    console.error('ユーザー作成エラー:', e.message);
  });

  req.write(userData);
  req.end();
}

// テストログイン
function testLogin() {
  const loginData = JSON.stringify({
    nickname: 'test',
    password: 'test123'
  });

  const options = {
    hostname: 'localhost',
    port: 3000,
    path: '/api/auth/login',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': loginData.length
    }
  };

  const req = http.request(options, (res) => {
    let data = '';
    res.on('data', (chunk) => data += chunk);
    res.on('end', () => {
      console.log('ログイン結果:', res.statusCode, data);
    });
  });

  req.on('error', (e) => {
    console.error('ログインエラー:', e.message);
  });

  req.write(loginData);
  req.end();
}

// 実行
console.log('テストユーザー作成とログインテスト開始...');
createTestUser();